//
//  MPGLL.hpp
//  MPWLTest
//
//  Created by Motita on 24/12/25.
//

#pragma once

#include "Source/GLTFLoader.hpp"
#include "Source/ImageLoader.hpp"

namespace MPGLL {

bool ReadBinaryFile(const std::string& path);

}
