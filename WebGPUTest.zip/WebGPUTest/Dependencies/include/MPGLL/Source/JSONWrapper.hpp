//
//  JSONWrapper.hpp
//  MPWLTest
//
//  Created by Motita on 24/12/25.
//

#pragma once

#include "../Include/yyjson.h"

namespace MPGLL {

namespace JSON {

class Value {
public:
    Value() = default;
    Value(yyjson_val* v) : m_Value(v) {}
    
    bool IsValid() const { return m_Value != nullptr; }
    bool IsObj() const { return m_Value && yyjson_is_obj(m_Value); }
    bool IsArr() const { return m_Value && yyjson_is_arr(m_Value); }
    bool IsStr() const { return m_Value && yyjson_is_str(m_Value); }
    bool IsNum() const { return m_Value && yyjson_is_num(m_Value); }
    
    Value GetObj(const char* key) const {
        return (IsObj()) ? Value(yyjson_obj_get(m_Value, key)) : Value();
    }
    
    Value GetArr(size_t index) const {
        return (IsArr()) ? Value(yyjson_arr_get(m_Value, index)) : Value();
    }
    
    size_t GetSize() const {
        return IsArr() ? yyjson_arr_size(m_Value) : 0;
    }
    
    const char* Str(const char* def = nullptr) const {
        return IsStr() ? yyjson_get_str(m_Value) : def;
    }
    
    uint32_t Uint(uint32_t def = 0) const {
        return IsNum() ? (uint32_t)yyjson_get_uint(m_Value) : def;
    }
    
    int32_t Int(int32_t def = 0) const {
        return IsNum() ? (int32_t)yyjson_get_int(m_Value) : def;
    }
    
    float Float(float def = 0.0f) const {
        return IsNum() ? (float)yyjson_get_real(m_Value) : def;
    }
    
    bool Bool(bool def = false) const {
        return m_Value ? yyjson_get_bool(m_Value) : def;
    }
    
    yyjson_val* GetHandle() const { return m_Value; }
    
private:
    yyjson_val* m_Value = nullptr;
};

class Document {
public:
    Document() = default;
    Document(yyjson_doc* doc) : m_Document(doc) {}
    
    ~Document() {
        if (m_Document) yyjson_doc_free(m_Document);
    }
    
    Document(Document&& other) noexcept : m_Document(other.m_Document) {
        other.m_Document = nullptr;
    }
    
    Document& operator=(Document&& other) noexcept {
        if (this != &other) {
            if (m_Document) yyjson_doc_free(m_Document);
            m_Document = other.m_Document;
            other.m_Document = nullptr;
        }
        return *this;
    }
    
    static Document ParseFile(const char* path) {
        yyjson_read_err err;
        yyjson_doc* doc = yyjson_read_file(path, 0, nullptr, &err);
        return Document(doc);
    }
    
    Value GetRoot() const {
        return Value(m_Document ? yyjson_doc_get_root(m_Document) : nullptr);
    }
    
    bool IsValid() const { return m_Document != nullptr; }
    
private:
    yyjson_doc* m_Document = nullptr;
};

}

}
