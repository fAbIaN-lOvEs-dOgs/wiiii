//
//  main.cpp
//  LearningWebGPU
//
//  Created by Motita on 10/01/26.
//

#include <GLFW/glfw3.h>
#include <GLFW/glfw3webgpu.h>
#include <webgpu/webgpu.h>

#include <MPGLL/MPGLL.hpp>

#include <iostream>

const char *shaderSource = R"(
    struct VSInput {
        @location(0) position : vec3<f32>,
        @location(1) color : vec4<f32>,
        @location(2) normal : vec3<f32>,
        @location(3) uv : vec2<f32>
    };

    struct VSOutput {
        @builtin(position) position : vec4<f32>,
        @location(0) color : vec4<f32>,
        @location(1) normal : vec3<f32>,
        @location(2) uv : vec2<f32>
    };

    @vertex
    
    fn VSMain(input : VSInput) -> VSOutput {
        var output : VSOutput;
        output.position = vec4<f32>((input.position / 2.0), 1.0);
        output.color = input.color;
        output.normal = input.normal;
        output.uv = input.uv;
        return output;
    }
    
    @fragment
    
    fn FSMain(input : VSOutput) -> @location(0) vec4<f32> {
        return vec4<f32>(input.normal, 1.0);
    }
)";

void OnDeviceError(const WGPUDevice *device, WGPUErrorType errorType, WGPUStringView message, void *userdata1, void *userdata2) {
    const char *type;
    
    switch (errorType) {
        case WGPUErrorType_Validation:
            type = "Validation";
            break;
            
        case WGPUErrorType_OutOfMemory:
            type = "Out Of Memory";
            break;
            
        case WGPUErrorType_NoError:
            type = "No Error";
            break;
            
        case WGPUErrorType_Internal:
            type = "Internal";
            break;
            
        case WGPUErrorType_Unknown:
            type = "Unknown";
            break;
            
        case WGPUErrorType_Force32:
            type = "Force 32";
            break;
            
        default:
            type = "Unknown";
            break;
    }
    
    std::cerr << "WGPU" << type << "Error: " << std::string(message.data, message.length) << std::endl;
}

void OnAdapter(WGPURequestAdapterStatus status, WGPUAdapter received, WGPUStringView message, void *userdata1, void *userdata2) {
    if (status != WGPURequestAdapterStatus_Success) {
        return;
    }
    
    *(WGPUAdapter*)userdata1 = received;
}

void OnDevice(WGPURequestDeviceStatus status, WGPUDevice received, WGPUStringView message, void *userdata1, void *userdata2) {
    if (status != WGPURequestDeviceStatus_Success) {
        return;
    }
    
    *(WGPUDevice*)userdata1 = received;
}

int main(int argc, const char * argv[]) {
    if (!glfwInit()) {
        return EXIT_FAILURE;
    }
    
    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
    
    GLFWwindow *window = glfwCreateWindow(800, 600, "Untitled", nullptr, nullptr);
    
    if (!window) {
        glfwTerminate();
        return EXIT_FAILURE;
    }
    
    MPGLL::GLTFLoader loader;
    
    if (!loader.Load("mouse.gltf")) {
        std::cerr << "Failed to load glTF file!" << std::endl;
        return EXIT_FAILURE;
    }
    
    const auto &meshes = loader.GetMeshes();
    
    if (meshes.empty()) {
        std::cerr << "Failed to find meshes in glTF file!" << std::endl;
        return EXIT_FAILURE;
    }
    
    const auto &mesh = meshes[0];
    
    const auto& vertices = mesh.Vertices;
    const auto& indices  = mesh.Indices;
    
    WGPUInstance instance = wgpuCreateInstance(nullptr);
    
    WGPUSurface surface = glfwCreateWindowWGPUSurface(instance, window);
    
    WGPUAdapter adapter = nullptr;
    
    WGPURequestAdapterOptions adapterOptions;
    adapterOptions.nextInChain = nullptr;
    adapterOptions.compatibleSurface = surface;
    
    WGPURequestAdapterCallbackInfo adapterCallbackInfo;
    adapterCallbackInfo.nextInChain = nullptr;
    adapterCallbackInfo.mode = WGPUCallbackMode_WaitAnyOnly;
    adapterCallbackInfo.callback = OnAdapter;
    adapterCallbackInfo.userdata1 = &adapter;
    
    wgpuInstanceRequestAdapter(instance, &adapterOptions, adapterCallbackInfo);
    
    while (!adapter) {
        wgpuInstanceProcessEvents(instance);
        glfwPollEvents();
    }
    
    WGPUDevice device = nullptr;
    
    WGPUUncapturedErrorCallbackInfo errorCallbackInfo;
    errorCallbackInfo.nextInChain = nullptr;
    errorCallbackInfo.callback = OnDeviceError;
    
    WGPUDeviceDescriptor deviceDescriptor;
    deviceDescriptor.nextInChain = nullptr;
    deviceDescriptor.label = (WGPUStringView){ "Device", WGPU_STRLEN };
    deviceDescriptor.uncapturedErrorCallbackInfo = errorCallbackInfo;
    
    WGPURequestDeviceCallbackInfo deviceCallbackInfo;
    deviceCallbackInfo.nextInChain = nullptr;
    deviceCallbackInfo.mode = WGPUCallbackMode_WaitAnyOnly;
    deviceCallbackInfo.callback = OnDevice;
    deviceCallbackInfo.userdata1 = &device;
    
    wgpuAdapterRequestDevice(adapter, &deviceDescriptor, deviceCallbackInfo);
    
    while (!device) {
        wgpuInstanceProcessEvents(instance);
        glfwPollEvents();
    }
    
    WGPUQueue queue = wgpuDeviceGetQueue(device);
    
    WGPUBufferDescriptor vertexBufferDescriptor;
    vertexBufferDescriptor.nextInChain = nullptr;
    vertexBufferDescriptor.size = vertices.size() * sizeof(MPGLL::Vertex);
    vertexBufferDescriptor.usage = WGPUBufferUsage_Vertex | WGPUBufferUsage_CopyDst;
    
    WGPUBuffer vertexBuffer = wgpuDeviceCreateBuffer(device, &vertexBufferDescriptor);
    
    wgpuQueueWriteBuffer(queue, vertexBuffer, 0, vertices.data(), vertices.size() * sizeof(MPGLL::Vertex));
    
    WGPUBufferDescriptor indexBufferDescriptor;
    indexBufferDescriptor.nextInChain = nullptr;
    indexBufferDescriptor.size = indices.size() * sizeof(uint32_t);
    indexBufferDescriptor.usage = WGPUBufferUsage_Index | WGPUBufferUsage_CopyDst;

    WGPUBuffer indexBuffer = wgpuDeviceCreateBuffer(device, &indexBufferDescriptor);

    wgpuQueueWriteBuffer(queue, indexBuffer, 0, indices.data(), indices.size() * sizeof(uint32_t));
    
    WGPUChainedStruct chainedStruct;
    chainedStruct.sType = WGPUSType_ShaderSourceWGSL;
    
    WGPUShaderSourceWGSL shaderCode;
    shaderCode.chain = chainedStruct;
    shaderCode.code = (WGPUStringView){ shaderSource, WGPU_STRLEN };
    
    WGPUShaderModuleDescriptor shaderDescriptor;
    shaderDescriptor.nextInChain = &shaderCode.chain;
    shaderDescriptor.label = (WGPUStringView){ "Shader", WGPU_STRLEN };
    
    WGPUShaderModule shader = wgpuDeviceCreateShaderModule(device, &shaderDescriptor);
    
    WGPUVertexAttribute vertexPositionAttribute;
    vertexPositionAttribute.format = WGPUVertexFormat_Float32x3;
    vertexPositionAttribute.offset = offsetof(MPGLL::Vertex, Position);
    vertexPositionAttribute.shaderLocation = 0;
    
    WGPUVertexAttribute vertexColorAttribute;
    vertexColorAttribute.format = WGPUVertexFormat_Float32x4;
    vertexColorAttribute.offset = offsetof(MPGLL::Vertex, Color);
    vertexColorAttribute.shaderLocation = 1;
    
    WGPUVertexAttribute vertexNormalAttribute;
    vertexNormalAttribute.format = WGPUVertexFormat_Float32x3;
    vertexNormalAttribute.offset = offsetof(MPGLL::Vertex, Normal);
    vertexNormalAttribute.shaderLocation = 2;
    
    WGPUVertexAttribute vertexTexCoordAttribute;
    vertexTexCoordAttribute.format = WGPUVertexFormat_Float32x2;
    vertexTexCoordAttribute.offset = offsetof(MPGLL::Vertex, Normal);
    vertexTexCoordAttribute.shaderLocation = 3;
    
    WGPUVertexAttribute vertexAttributes[4] {
        vertexPositionAttribute, vertexColorAttribute, vertexNormalAttribute, vertexTexCoordAttribute
    };
    
    WGPUVertexBufferLayout vertexBufferLayout;
    vertexBufferLayout.stepMode = WGPUVertexStepMode_Vertex;
    vertexBufferLayout.arrayStride = sizeof(MPGLL::Vertex);
    vertexBufferLayout.attributeCount = 4;
    vertexBufferLayout.attributes = vertexAttributes;
    
    WGPUVertexState vertexState;
    vertexState.nextInChain = nullptr;
    vertexState.module = shader;
    vertexState.entryPoint = (WGPUStringView){ "VSMain", WGPU_STRLEN };
    vertexState.bufferCount = 1;
    vertexState.buffers = &vertexBufferLayout;
    
    WGPUSurfaceCapabilities surfaceCapabilities;
    
    wgpuSurfaceGetCapabilities(surface, adapter, &surfaceCapabilities);
    
    WGPUTextureFormat format = surfaceCapabilities.formats[0];
    
    wgpuSurfaceCapabilitiesFreeMembers(surfaceCapabilities);
    
    WGPUColorTargetState colorTarget;
    colorTarget.nextInChain = nullptr;
    colorTarget.format = format;
    colorTarget.writeMask = WGPUColorWriteMask_All;
    
    WGPUFragmentState fragmentState;
    fragmentState.nextInChain = nullptr;
    fragmentState.module = shader;
    fragmentState.entryPoint = (WGPUStringView){ "FSMain", WGPU_STRLEN };
    fragmentState.targetCount = 1;
    fragmentState.targets = &colorTarget;
    
    WGPUPrimitiveState primitiveState;
    primitiveState.nextInChain = nullptr;
    primitiveState.topology = WGPUPrimitiveTopology_TriangleList;
    
    WGPUMultisampleState multisampleState;
    multisampleState.nextInChain = nullptr;
    multisampleState.count = 1;
    multisampleState.mask = 0xFFFFFFFF;
    multisampleState.alphaToCoverageEnabled = false;
    
    WGPUPipelineLayoutDescriptor pipelineLayoutDescriptor;
    pipelineLayoutDescriptor.nextInChain = nullptr;
    pipelineLayoutDescriptor.bindGroupLayoutCount = 0;
    pipelineLayoutDescriptor.bindGroupLayouts = nullptr;
    
    WGPUPipelineLayout pipelineLayout = wgpuDeviceCreatePipelineLayout(device, &pipelineLayoutDescriptor);
    
    WGPURenderPipelineDescriptor pipelineDescriptor;
    pipelineDescriptor.layout = pipelineLayout;
    pipelineDescriptor.nextInChain = nullptr;
    pipelineDescriptor.vertex = vertexState;
    pipelineDescriptor.fragment = &fragmentState;
    pipelineDescriptor.primitive = primitiveState;
    pipelineDescriptor.multisample = multisampleState;
    
    WGPURenderPipeline pipeline = wgpuDeviceCreateRenderPipeline(device, &pipelineDescriptor);
    
    int width;
    int height;
    
    glfwGetFramebufferSize(window, &width, &height);
    
    WGPUSurfaceConfiguration surfaceConfiguration;
    surfaceConfiguration.device = device;
    surfaceConfiguration.format = format;
    surfaceConfiguration.usage = WGPUTextureUsage_RenderAttachment;
    surfaceConfiguration.width = (uint32_t)width;
    surfaceConfiguration.height = (uint32_t)height;
    surfaceConfiguration.presentMode = WGPUPresentMode_Fifo;
    surfaceConfiguration.alphaMode = WGPUCompositeAlphaMode_Auto;
    
    wgpuSurfaceConfigure(surface, &surfaceConfiguration);
    
    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        
        glfwGetFramebufferSize(window, &width, &height);
        
        if (!width || !height) {
            continue;
        }
        
        surfaceConfiguration.width = (uint32_t)width;
        surfaceConfiguration.height = (uint32_t)height;
        
        wgpuSurfaceConfigure(surface, &surfaceConfiguration);
        
        WGPUSurfaceTexture surfaceTexture;
        
        wgpuSurfaceGetCurrentTexture(surface, &surfaceTexture);
        
        if (surfaceTexture.status != WGPUSurfaceGetCurrentTextureStatus_SuccessOptimal) {
            continue;
        }
        
        WGPUTextureView view = wgpuTextureCreateView(surfaceTexture.texture, nullptr);
        
        WGPUCommandEncoder commandEncoder = wgpuDeviceCreateCommandEncoder(device, nullptr);
        
        WGPURenderPassColorAttachment colorAttachment;
        colorAttachment.view = view;
        colorAttachment.depthSlice = WGPU_DEPTH_SLICE_UNDEFINED;
        colorAttachment.loadOp = WGPULoadOp_Clear;
        colorAttachment.storeOp = WGPUStoreOp_Store;
        colorAttachment.clearValue = { 0.1, 0.1, 0.1, 1.0 };
        
        WGPURenderPassDescriptor renderPassDescriptor = {
            .colorAttachmentCount = 1,
            .colorAttachments = &colorAttachment,
        };
        
        WGPURenderPassEncoder renderPassEncoder = wgpuCommandEncoderBeginRenderPass(commandEncoder, &renderPassDescriptor);
        
        wgpuRenderPassEncoderSetPipeline(renderPassEncoder, pipeline);
        wgpuRenderPassEncoderSetViewport(renderPassEncoder, 0.0f, 0.0f, (float)width, (float)height, 0.0f, 1.0f);
        wgpuRenderPassEncoderSetScissorRect(renderPassEncoder, 0, 0, (uint32_t)width, (uint32_t)height);
        wgpuRenderPassEncoderSetVertexBuffer(renderPassEncoder, 0, vertexBuffer, 0, WGPU_WHOLE_SIZE);
        wgpuRenderPassEncoderSetIndexBuffer(renderPassEncoder, indexBuffer, WGPUIndexFormat_Uint32, 0, WGPU_WHOLE_SIZE);
        wgpuRenderPassEncoderDrawIndexed( renderPassEncoder, static_cast<uint32_t>(indices.size()), 1, 0, 0, 0);
        wgpuRenderPassEncoderEnd(renderPassEncoder);
        
        WGPUCommandBuffer commandBuffer = wgpuCommandEncoderFinish(commandEncoder, nullptr);
        
        wgpuQueueSubmit(queue, 1, &commandBuffer);
        wgpuSurfacePresent(surface);
        
        wgpuCommandBufferRelease(commandBuffer);
        wgpuCommandEncoderRelease(commandEncoder);
        wgpuTextureViewRelease(view);
    }
    
    return EXIT_SUCCESS;
}
