//
//  GLTFLoader.hpp
//  MPWLTest
//
//  Created by Motita on 24/12/25.
//

#pragma once

#include <iostream>
#include <cstring>
#include <vector>

namespace MPGLL {

struct Vector2 {
    float x;
    float y;
};

struct Vector3 {
    float x;
    float y;
    float z;
};

struct Vector4 {
    float x;
    float y;
    float z;
    float w;
};

struct Vertex {
    Vector3 Position;
    Vector4 Color;
    Vector3 Normal;
    Vector2 TexCoord;
};

struct Mesh {
    std::vector<Vertex> Vertices;
    std::vector<uint32_t> Indices;
};

class GLTFLoader {
public:
    bool Load(const std::string& path);
    const std::vector<Mesh>& GetMeshes() const { return m_Meshes; }

private:
    struct Buffer {
        std::vector<uint8_t> data;
    };

    struct BufferView {
        uint32_t buffer;
        size_t offset;
        size_t length;
        size_t stride;
    };

    struct Accessor {
        uint32_t bufferView;
        size_t offset;
        size_t count;
        uint32_t componentType;
        const char* type;
    };

    std::vector<Buffer>     m_Buffers;
    std::vector<BufferView> m_BufferViews;
    std::vector<Accessor>   m_Accessors;
    std::vector<Mesh>       m_Meshes;

    template<typename T>
    std::vector<T> ReadAccessor(uint32_t index) {
        const Accessor& acc = m_Accessors[index];
        const BufferView& view = m_BufferViews[acc.bufferView];
        const Buffer& buf = m_Buffers[view.buffer];

        size_t stride = view.stride ? view.stride : sizeof(T);
        const uint8_t* base = buf.data.data() + view.offset + acc.offset;

        std::vector<T> out(acc.count);

        for (size_t i = 0; i < acc.count; i++) {
            const uint8_t* src = base + i * stride;

            switch (acc.componentType) {
                case 5126:
                    memcpy(&out[i], src, sizeof(T));
                    break;
                case 5123: {
                    uint16_t val;
                    memcpy(&val, src, sizeof(uint16_t));
                    out[i] = static_cast<T>(val);
                    break;
                }
                case 5125: {
                    uint32_t val;
                    memcpy(&val, src, sizeof(uint32_t));
                    out[i] = static_cast<T>(val);
                    break;
                }
                case 5121: {
                    uint8_t val;
                    memcpy(&val, src, sizeof(uint8_t));
                    out[i] = static_cast<T>(val);
                    break;
                }
                default:
                    throw std::runtime_error("Unsupported componentType");
            }
        }

        return out;
    }
    
    std::vector<uint32_t> ReadIndices(uint32_t index) {
        const Accessor& acc = m_Accessors[index];
        const BufferView& view = m_BufferViews[acc.bufferView];
        const Buffer& buf = m_Buffers[view.buffer];

        const uint8_t* base = buf.data.data() + view.offset + acc.offset;
        std::vector<uint32_t> out(acc.count);

        switch (acc.componentType) {
            case 5121: {
                for (size_t i = 0; i < acc.count; i++) {
                    out[i] = *(base + i);
                }
                break;
            }
            case 5123: {
                const uint16_t* src = reinterpret_cast<const uint16_t*>(base);
                for (size_t i = 0; i < acc.count; i++) {
                    out[i] = src[i];
                }
                break;
            }
            case 5125: {
                const uint32_t* src = reinterpret_cast<const uint32_t*>(base);
                for (size_t i = 0; i < acc.count; i++) {
                    out[i] = src[i];
                }
                break;
            }
            default:
                throw std::runtime_error("Unsupported index componentType");
        }

        return out;
    }


};

}
