//
//  GLTFLoader.cpp
//  MPWLTest
//
//  Created by Motita on 24/12/25.
//

#include "GLTFLoader.hpp"
#include "JSONWrapper.hpp"

#include <fstream>

namespace MPGLL {

bool ReadBinaryFile(const std::string& path, std::vector<uint8_t>& out) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open())
        return false;
    
    out.assign(std::istreambuf_iterator<char>(file), {});
    return true;
}

bool GLTFLoader::Load(const std::string& path) {
    std::string baseDir = path.substr(0, path.find_last_of('/') + 1);
    
    JSON::Document doc = JSON::Document::ParseFile(path.c_str());
    if (!doc.IsValid())
        return false;
    
    JSON::Value root = doc.GetRoot();
    
    JSON::Value buffers = root.GetObj("buffers");
    for (size_t i = 0; i < buffers.GetSize(); i++) {
        JSON::Value b = buffers.GetArr(i);
        
        Buffer buf;
        if (!ReadBinaryFile(baseDir + b.GetObj("uri").Str(), buf.data))
            return false;
        
        m_Buffers.push_back(std::move(buf));
    }
    
    JSON::Value views = root.GetObj("bufferViews");
    for (size_t i = 0; i < views.GetSize(); i++) {
        JSON::Value v = views.GetArr(i);
        m_BufferViews.push_back({
            v.GetObj("buffer").Uint(),
            (size_t)v.GetObj("byteOffset").Uint(),
            (size_t)v.GetObj("byteLength").Uint(),
            (size_t)v.GetObj("byteStride").Uint()
        });
    }
    
    JSON::Value accs = root.GetObj("accessors");
    for (size_t i = 0; i < accs.GetSize(); i++) {
        JSON::Value a = accs.GetArr(i);
        m_Accessors.push_back({
            a.GetObj("bufferView").Uint(),
            (size_t)a.GetObj("byteOffset").Uint(),
            (size_t)a.GetObj("count").Uint(),
            a.GetObj("componentType").Uint(),
            a.GetObj("type").Str()
        });
    }
    
    JSON::Value meshes = root.GetObj("meshes");
    for (size_t m = 0; m < meshes.GetSize(); m++) {
        JSON::Value prims = meshes.GetArr(m).GetObj("primitives");
        for (size_t p = 0; p < prims.GetSize(); p++) {
            Mesh out;
            
            JSON::Value prim = prims.GetArr(p);
            JSON::Value attrs = prim.GetObj("attributes");

            if (attrs.GetObj("POSITION").IsValid()) {
                auto positions = ReadAccessor<Vector3>(attrs.GetObj("POSITION").Uint());
                out.Vertices.resize(positions.size());
                for (size_t i = 0; i < positions.size(); i++) {
                    out.Vertices[i].Position = positions[i];
                }
            }

            if (attrs.GetObj("COLOR_0").IsValid()) {
                auto colors = ReadAccessor<Vector4>(attrs.GetObj("COLOR_0").Uint());
                for (size_t i = 0; i < colors.size(); i++) {
                    out.Vertices[i].Color = colors[i];
                }
            }

            if (attrs.GetObj("NORMAL").IsValid()) {
                auto normals = ReadAccessor<Vector3>(attrs.GetObj("NORMAL").Uint());
                for (size_t i = 0; i < normals.size(); i++) {
                    out.Vertices[i].Normal = normals[i];
                }
            }

            if (attrs.GetObj("TEXCOORD_0").IsValid()) {
                auto uvs = ReadAccessor<Vector2>(attrs.GetObj("TEXCOORD_0").Uint());
                for (size_t i = 0; i < uvs.size(); i++) {
                    out.Vertices[i].TexCoord = uvs[i];
                }
            }

            if (prim.GetObj("indices").IsValid()) {
                out.Indices = ReadIndices(prim.GetObj("indices").Uint());
            }

            m_Meshes.push_back(std::move(out));

        }
    }
    
    return true;
}

}
