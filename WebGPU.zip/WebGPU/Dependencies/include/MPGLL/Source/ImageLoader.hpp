//
//  ImageLoader.hpp
//  MPWLTest
//
//  Created by Motita on 24/12/25.
//

#pragma once

#include "../Include/png.h"

namespace MPGLL {

struct Image {
    int width;
    int height;
    int channels;
    std::vector<uint8_t> pixels;
};

Image LoadImage(const char* filename) {
    FILE* fp = std::fopen(filename, "rb");
    if (!fp) {
        std::cout << "Failed to open file: " << filename << std::endl;
    }

    unsigned char header[8];
    fread(header, 1, 8, fp);
    if (png_sig_cmp(header, 0, 8)) {
        std::cout << "File is not a valid PNG: " << filename << std::endl;
        std::fclose(fp);
    }

    png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, nullptr, nullptr, nullptr);
    if (!png_ptr) {
        std::cout << "Failed to create PNG read struct!" << std::endl;
        std::fclose(fp);
    }

    png_infop info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr) {
        std::cout << "Failed to create PNG info struct!" << std::endl;
        png_destroy_read_struct(&png_ptr, nullptr, nullptr);
        std::fclose(fp);
    }

    if (setjmp(png_jmpbuf(png_ptr))) {
        std::cout << "Failed to decode: " << filename << std::endl;
        png_destroy_read_struct(&png_ptr, &info_ptr, nullptr);
        std::fclose(fp);
    }

    png_init_io(png_ptr, fp);
    png_set_sig_bytes(png_ptr, 8);

    png_read_info(png_ptr, info_ptr);

    png_uint_32 width, height;
    int bit_depth, color_type;
    png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type, nullptr, nullptr, nullptr);

    if (bit_depth == 16) {
        png_set_strip_16(png_ptr);
    }

    if (color_type == PNG_COLOR_TYPE_PALETTE) {
        png_set_palette_to_rgb(png_ptr);
    }

    if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) {
        png_set_expand_gray_1_2_4_to_8(png_ptr);
    }

    if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) {
        png_set_tRNS_to_alpha(png_ptr);
    }

    if (color_type == PNG_COLOR_TYPE_RGB || color_type == PNG_COLOR_TYPE_GRAY || color_type == PNG_COLOR_TYPE_PALETTE) {
        png_set_filler(png_ptr, 0xFF, PNG_FILLER_AFTER);
    }

    if (color_type == PNG_COLOR_TYPE_GRAY || color_type == PNG_COLOR_TYPE_GRAY_ALPHA) {
        png_set_gray_to_rgb(png_ptr);
    }

    (void)png_set_interlace_handling(png_ptr);
    
    png_read_update_info(png_ptr, info_ptr);
    
    Image image;
    image.width = width;
    image.height = height;
    image.channels = 4;
    image.pixels.resize(width * height * 4);

    std::vector<png_bytep> row_pointers(height);
    for (size_t y = 0; y < height; y++)
        row_pointers[y] = image.pixels.data() + y * width * 4;

    png_read_image(png_ptr, row_pointers.data());
    png_read_end(png_ptr, nullptr);
    
    png_destroy_read_struct(&png_ptr, &info_ptr, nullptr);
    fclose(fp);

    return image;
}

}
